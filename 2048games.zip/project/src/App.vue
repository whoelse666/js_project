<script setup lang="ts">
import Game2048 from './components/Game2048.vue'
</script>

<template>
  <div class="app">
    <h1>2048 Game</h1>
    <Game2048 />
  </div>
</template>

<style>
.app {
  font-family: Arial, sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #faf8ef;
}

h1 {
  color: #776e65;
}
</style>