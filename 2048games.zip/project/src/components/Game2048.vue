<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'

const grid = ref<number[][]>([[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]])
const score = ref(0)

const cellColor = (value: number) => {
  const colors: { [key: number]: string } = {
    2: '#eee4da',
    4: '#ede0c8',
    8: '#f2b179',
    16: '#f59563',
    32: '#f67c5f',
    64: '#f65e3b',
    128: '#edcf72',
    256: '#edcc61',
    512: '#edc850',
    1024: '#edc53f',
    2048: '#edc22e'
  }
  return colors[value] || '#cdc1b4'
}

const cellTextColor = (value: number) => {
  return value <= 4 ? '#776e65' : '#f9f6f2'
}

const initGame = () => {
  grid.value = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
  score.value = 0
  addNewTile()
  addNewTile()
}

const addNewTile = () => {
  const emptyTiles = []
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (grid.value[i][j] === 0) {
        emptyTiles.push({ row: i, col: j })
      }
    }
  }
  if (emptyTiles.length > 0) {
    const { row, col } = emptyTiles[Math.floor(Math.random() * emptyTiles.length)]
    grid.value[row][col] = Math.random() < 0.9 ? 2 : 4
  }
}

const moveLeft = () => {
  let moved = false
  for (let i = 0; i < 4; i++) {
    const row = grid.value[i].filter(cell => cell !== 0)
    for (let j = 0; j < row.length - 1; j++) {
      if (row[j] === row[j + 1]) {
        row[j] *= 2
        score.value += row[j]
        row[j + 1] = 0
        moved = true
      }
    }
    const newRow = row.filter(cell => cell !== 0)
    while (newRow.length < 4) {
      newRow.push(0)
    }
    if (newRow.join(',') !== grid.value[i].join(',')) {
      moved = true
    }
    grid.value[i] = newRow
  }
  return moved
}

const moveRight = () => {
  let moved = false
  for (let i = 0; i < 4; i++) {
    const row = grid.value[i].filter(cell => cell !== 0)
    for (let j = row.length - 1; j > 0; j--) {
      if (row[j] === row[j - 1]) {
        row[j] *= 2
        score.value += row[j]
        row[j - 1] = 0
        moved = true
      }
    }
    const newRow = row.filter(cell => cell !== 0)
    while (newRow.length < 4) {
      newRow.unshift(0)
    }
    if (newRow.join(',') !== grid.value[i].join(',')) {
      moved = true
    }
    grid.value[i] = newRow
  }
  return moved
}

const moveUp = () => {
  let moved = false
  for (let j = 0; j < 4; j++) {
    const column = [grid.value[0][j], grid.value[1][j], grid.value[2][j], grid.value[3][j]].filter(cell => cell !== 0)
    for (let i = 0; i < column.length - 1; i++) {
      if (column[i] === column[i + 1]) {
        column[i] *= 2
        score.value += column[i]
        column[i + 1] = 0
        moved = true
      }
    }
    const newColumn = column.filter(cell => cell !== 0)
    while (newColumn.length < 4) {
      newColumn.push(0)
    }
    if (newColumn.join(',') !== [grid.value[0][j], grid.value[1][j], grid.value[2][j], grid.value[3][j]].join(',')) {
      moved = true
    }
    for (let i = 0; i < 4; i++) {
      grid.value[i][j] = newColumn[i]
    }
  }
  return moved
}

const moveDown = () => {
  let moved = false
  for (let j = 0; j < 4; j++) {
    const column = [grid.value[0][j], grid.value[1][j], grid.value[2][j], grid.value[3][j]].filter(cell => cell !== 0)
    for (let i = column.length - 1; i > 0; i--) {
      if (column[i] === column[i - 1]) {
        column[i] *= 2
        score.value += column[i]
        column[i - 1] = 0
        moved = true
      }
    }
    const newColumn = column.filter(cell => cell !== 0)
    while (newColumn.length < 4) {
      newColumn.unshift(0)
    }
    if (newColumn.join(',') !== [grid.value[0][j], grid.value[1][j], grid.value[2][j], grid.value[3][j]].join(',')) {
      moved = true
    }
    for (let i = 0; i < 4; i++) {
      grid.value[i][j] = newColumn[i]
    }
  }
  return moved
}

const handleKeyDown = (event: KeyboardEvent) => {
  let moved = false
  switch (event.key) {
    case 'ArrowLeft':
      moved = moveLeft()
      break
    case 'ArrowRight':
      moved = moveRight()
      break
    case 'ArrowUp':
      moved = moveUp()
      break
    case 'ArrowDown':
      moved = moveDown()
      break
  }
  if (moved) {
    addNewTile()
  }
}

const isGameOver = computed(() => {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (grid.value[i][j] === 0) {
        return false
      }
      if (i < 3 && grid.value[i][j] === grid.value[i + 1][j]) {
        return false
      }
      if (j < 3 && grid.value[i][j] === grid.value[i][j + 1]) {
        return false
      }
    }
  }
  return true
})

onMounted(() => {
  initGame()
  window.addEventListener('keydown', handleKeyDown)
})
</script>

<template>
  <div class="game-container">
    <div class="score">Score: {{ score }}</div>
    <div class="grid">
      <div v-for="(row, rowIndex) in grid" :key="rowIndex" class="row">
        <div v-for="(cell, cellIndex) in row" :key="cellIndex" class="cell" :style="{ backgroundColor: cellColor(cell) }">
          <span :style="{ color: cellTextColor(cell) }">{{ cell !== 0 ? cell : '' }}</span>
        </div>
      </div>
    </div>
    <div v-if="isGameOver" class="game-over">
      Game Over!
      <button @click="initGame">New Game</button>
    </div>
  </div>
</template>

<style scoped>
.game-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.score {
  font-size: 24px;
  margin-bottom: 20px;
  color: #776e65;
}

.grid {
  display: grid;
  grid-template-rows: repeat(4, 1fr);
  gap: 10px;
  background-color: #bbada0;
  border-radius: 6px;
  padding: 10px;
}

.row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.cell {
  width: 80px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 24px;
  font-weight: bold;
  border-radius: 4px;
}

.game-over {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(238, 228, 218, 0.73);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 48px;
  color: #776e65;
}

button {
  margin-top: 20px;
  padding: 10px 20px;
  font-size: 18px;
  background-color: #8f7a66;
  color: #f9f6f2;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #9f8b77;
}
</style>